import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {

    def body = message.getBody(String)
    def json = new JsonSlurper().parseText(body)

    def isValid = true
    def errorMsg = ""

    if (!json.orderId) {
        isValid = false
        errorMsg += "Missing orderId. "
    }

    if (!json.customerName) {
        isValid = false
        errorMsg += "Missing customerName. "
    }

    if (!json.amount || json.amount <= 0) {
        isValid = false
        errorMsg += "Invalid amount. "
    }

    // ✅ Only set properties
    message.setProperty("isValid", isValid.toString())
    message.setProperty("errorMsg", errorMsg)

    // ❗ DO NOT change body
    return message
}